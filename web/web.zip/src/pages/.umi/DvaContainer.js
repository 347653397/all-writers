import { Component } from 'react';
import dva from 'dva';
import createLoading from 'dva-loading';

const app = dva({
  history: window.g_history,
});
window.g_app = app;
app.use(createLoading());

app.model({ ...(require('../../models/example.js').default) });
app.model({ ...(require('../../pages/detai/models/index.js').default) });
app.model({ ...(require('../../pages/home/models/index.js').default) });
app.model({ ...(require('../../pages/login/models/login.js').default) });
app.model({ ...(require('../../pages/users/models/users.js').default) });

class DvaContainer extends Component {
  render() {
    app.router(() => this.props.children);
    return app.start()();
  }
}

export default DvaContainer;
