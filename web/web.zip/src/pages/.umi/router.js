import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/_renderRoutes';
import { routerRedux } from 'dva/router';


let Router = DefaultRouter;
const { ConnectedRouter } = routerRedux;
Router = ConnectedRouter;


let routes = [
  {
    "path": "/",
    "component": require('../../layouts/index.js').default,
    "routes": [
      {
        "path": "/detai",
        "exact": true,
        "component": require('../detai/index.js').default
      },
      {
        "path": "/detai/list",
        "exact": true,
        "component": require('../detai/list.js').default
      },
      {
        "path": "/home/adviser_tab3",
        "exact": true,
        "component": require('../home/adviser_tab3.js').default
      },
      {
        "path": "/home/selected_tab1",
        "exact": true,
        "component": require('../home/selected_tab1.js').default
      },
      {
        "path": "/home/story_tab2",
        "exact": true,
        "component": require('../home/story_tab2.js').default
      },
      {
        "path": "/home/world_tab4",
        "exact": true,
        "component": require('../home/world_tab4.js').default
      },
      {
        "path": "/login",
        "exact": true,
        "component": require('../login/index.js').default
      },
      {
        "path": "/users/comment",
        "exact": true,
        "component": require('../users/comment.js').default
      },
      {
        "path": "/users",
        "exact": true,
        "component": require('../users/index.js').default
      },
      {
        "path": "/users/detai",
        "exact": true,
        "component": require('../users/detai.js').default
      },
      {
        "path": "/users/forward",
        "exact": true,
        "component": require('../users/forward.js').default
      },
      {
        "path": "/users/order",
        "exact": true,
        "component": require('../users/order.js').default
      },
      {
        "path": "/users/proposal",
        "exact": true,
        "component": require('../users/proposal.js').default
      },
      {
        "path": "/users/help",
        "exact": true,
        "component": require('../users/help.js').default
      },
      {
        "path": "/",
        "exact": true,
        "component": require('../index.js').default
      },
      {
        "component": () => React.createElement(require('F:/scenarist/web/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', routes: '[{"path":"/","component":"./src\\\\layouts\\\\index.js","routes":[{"path":"/detai/components/comment","exact":true,"component":"./src/pages/detai/components/comment.js"},{"path":"/users/components/Users","exact":true,"component":"./src/pages/users/components/Users.js"},{"path":"/detai/components/ProgressBar","exact":true,"component":"./src/pages/detai/components/ProgressBar.js"},{"path":"/detai/components/tab","exact":true,"component":"./src/pages/detai/components/tab.js"},{"path":"/detai","exact":true,"component":"./src/pages/detai/index.js"},{"path":"/detai/list","exact":true,"component":"./src/pages/detai/list.js"},{"path":"/detai/models","exact":true,"component":"./src/pages/detai/models/index.js"},{"path":"/detai/services","exact":true,"component":"./src/pages/detai/services/index.js"},{"path":"/home/adviser_tab3","exact":true,"component":"./src/pages/home/adviser_tab3.js"},{"path":"/home/components/list","exact":true,"component":"./src/pages/home/components/list.js"},{"path":"/home/models","exact":true,"component":"./src/pages/home/models/index.js"},{"path":"/home/selected_tab1","exact":true,"component":"./src/pages/home/selected_tab1.js"},{"path":"/home/services","exact":true,"component":"./src/pages/home/services/index.js"},{"path":"/home/story_tab2","exact":true,"component":"./src/pages/home/story_tab2.js"},{"path":"/home/world_tab4","exact":true,"component":"./src/pages/home/world_tab4.js"},{"path":"/detai/components/music","exact":true,"component":"./src/pages/detai/components/music.js"},{"path":"/login","exact":true,"component":"./src/pages/login/index.js"},{"path":"/login/models/login","exact":true,"component":"./src/pages/login/models/login.js"},{"path":"/login/services/login","exact":true,"component":"./src/pages/login/services/login.js"},{"path":"/users/comment","exact":true,"component":"./src/pages/users/comment.js"},{"path":"/users/components/UserModal","exact":true,"component":"./src/pages/users/components/UserModal.js"},{"path":"/users/models/users","exact":true,"component":"./src/pages/users/models/users.js"},{"path":"/users/services/users","exact":true,"component":"./src/pages/users/services/users.js"},{"path":"/users","exact":true,"component":"./src/pages/users/index.js"},{"path":"/users/detai","exact":true,"component":"./src/pages/users/detai.js"},{"path":"/users/forward","exact":true,"component":"./src/pages/users/forward.js"},{"path":"/users/order","exact":true,"component":"./src/pages/users/order.js"},{"path":"/users/proposal","exact":true,"component":"./src/pages/users/proposal.js"},{"path":"/users/help","exact":true,"component":"./src/pages/users/help.js"},{"path":"/","exact":true,"component":"./src/pages/index.js"}]}]' })
      }
    ]
  }
];


export default function() {
  return (
<Router history={window.g_history}>
  <Route render={({ location }) =>
    renderRoutes(routes, {}, { location })
  } />
</Router>
  );
}
