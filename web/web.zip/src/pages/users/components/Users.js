import { connect } from 'dva';
import { Component } from 'react';
import styles from './Users.css';

const User = () => {
  return <div>324324234</div>
}

export default User
