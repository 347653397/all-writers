import * as usersService from '../services/users';
import { Toast } from 'antd-mobile';
import { routerRedux } from 'dva/router';

export default {
  namespace: 'users',
  state: {
    phone: '',
    cash_balance: '',
    userData: [],
    orderData: [],
    orderSel: '',
    toReward: [],
    moenyPageNum: 1,
    moenyPageSize: 12,
    toRewardTotal: 0,
    moenyLength: true,
    //提现
    forwardStatus: false,
    refreshDetai: '',
    //我的评论
    commentPageNum: 1,
    commentPageSize: 12,
    commentData: [],
    commentLength: true,
    refreshComment: '',
    //帮助中心
    helpData: [{
      title: '所获得打赏怎么提现？',
      content: '提现的流程为：1.进入个人中心，点击提现按钮； 2.若未绑定银行账号则先填写绑定银行账号； 3.填写提现金额，点击确认提交审核； 4.通过审核打款到指定银行账户',
      display: false,
    }, {
      title: '所获得打赏怎么提现？',
      content: '提现的流程为：1.进入个人中心，点击提现按钮； 2.若未绑定银行账号则先填写绑定银行账号； 3.填写提现金额，点击确认提交审核； 4.通过审核打款到指定银行账户',
      display: false,
    }, {
      title: '所获得打赏怎么提现？',
      content: '提现的流程为：1.进入个人中心，点击提现按钮； 2.若未绑定银行账号则先填写绑定银行账号； 3.填写提现金额，点击确认提交审核； 4.通过审核打款到指定银行账户',
      display: false,
    }, {
      title: '所获得打赏怎么提现？',
      content: '提现的流程为：1.进入个人中心，点击提现按钮； 2.若未绑定银行账号则先填写绑定银行账号； 3.填写提现金额，点击确认提交审核； 4.通过审核打款到指定银行账户',
      display: false,
    }, {
      title: '所获得打赏怎么提现？',
      content: '提现的流程为：1.进入个人中心，点击提现按钮； 2.若未绑定银行账号则先填写绑定银行账号； 3.填写提现金额，点击确认提交审核； 4.通过审核打款到指定银行账户',
      display: false,
    }],
    //建议
    commentProposal: '',
  },
  reducers: {
    save(state, action) {
      return {
        ...state, ...action.payload
      };
    },
  },
  effects: {
    *userCenter({ payload }, { call, put, select }) {
      const { data } = yield call(usersService.userCenter, payload);
      if (data.status == 200) {
        yield put({ type: 'save', payload: { userData: data.data } })
      }
    },
    *applyWithdraw({ payload }, { call, put, select }) {
      const { data } = yield call(usersService.applyWithdraw, payload);
      if (data.status == 200) {
        yield put({ type: 'save', payload: { forwardStatus: true } })
        // Toast.info('提交成功',1)

      } else {
        Toast.info(data.msg, 1)
      }
    },
    *myOrderlist({ payload }, { call, put, select }) {
      const { data } = yield call(usersService.myOrderlist, payload);
      if (data.status == 200) {
        yield put({ type: 'save', payload: { orderData: data.data } })
      }
    },
    *toRewardDetails({ payload }, { call, put, select }) {
      const { moenyPageNum, moenyPageSize, toReward, refreshDetai } = yield select(state => state.users);
      const { data } = yield call(usersService.toRewardDetails, { page: moenyPageNum, pageSize: moenyPageSize });
      if (data.status == 200) {
        toReward.push(...data.data.list)
        yield put({ type: 'save', payload: { toReward: toReward, toRewardTotal: data.data.total, moenyLength: data.data.list.length < moenyPageSize ? false : true, moenyPageNum: moenyPageNum + 1 } })
        refreshDetai && refreshDetai()
      }
    },
    *myComment({ payload }, { call, put, select }) {
      const { commentPageNum, refreshComment, commentPageSize, commentData } = yield select(state => state.users);
      const { data } = yield call(usersService.myComment, { page: commentPageNum, pageSize: commentPageSize });
      if (data.status == 200) {
        commentData.push(...data.data.list);
        yield put({ type: 'save', payload: { pullUpStatus: 0, commentData: commentData, Commentotal: data.data.total, commentLength: data.data.list.length < commentPageSize ? false : true, commentPageNum: commentPageNum + 1 } })
        refreshComment && refreshComment()
      }
    },

    *deleteFailOrder({ payload }, { call, put, select }) {
      const { data } = yield call(usersService.deleteFailOrder, payload);
      if (data.status == 200) {
        Toast.info('删除成功', 1);
        yield put({ type: 'myOrderlist' })
      } else {
        Toast.info(data.msg, 1)
      }
    },
    *submitFeedback({ payload }, { call, put, select }) {
      const { data } = yield call(usersService.submitFeedback, payload);
      if (data.status == 200) {
        //  yield put({type:'save',payload:{userData:data.data}})
        Toast.info('提交成功', 1)
        window.history.go(-1);
      } else {
        Toast.info(data.msg, 1)
      }
    },
    *usersRouter({ payload }, { call, put }) {
      yield put(routerRedux.push(payload.router))
    }
  },
  subscriptions: {
    setup({ dispatch, history }) {
      return history.listen(({ pathname, query }) => {
        switch (pathname) {
          case '/':
            document.title = '人人编剧'
            break;
          case '/login':
            document.title = '手机号绑定'
            break;
          case '/users':
            document.title = '我的主页';
            dispatch({ type: 'userCenter' })
            break;
          case '/users/detai':
            document.title = '我的钱包';
            dispatch({ type: 'userCenter' })
            dispatch({ type: 'save', payload: { toReward: [], moenyPageNum: 1, moenyLength: true, refreshDetai: '' } })
            break;
          case '/users/comment':
            document.title = '我的评论';
            dispatch({ type: 'save', payload: { commentPageNum: 1, commentData: [], commentLength: true, refreshComment: '' } })
            break;
          case '/users/forward':
            document.title = '提现申请';
            dispatch({ type: 'userCenter' })
            dispatch({ type: 'save', payload: { cash_balance: '', forwardStatus: false } })
            break;
          case '/users/order':
            document.title = '我的订单';
            dispatch({ type: 'save', payload: { commentVisible: false } })
            dispatch({ type: 'myOrderlist' })
            break;
          case '/users/proposal':
            document.title = '意见建议'
            break;
          case '/users/help':
            document.title = '帮助中心'
            break;
          default:
            break;
        }

      });
    },
  },
};
