import PxToRem from "postcss-pxtorem";

export default {
  "publicPath": "http://pre.startechsoft.cn/dist/static/",
  "theme": "./theme.config.js",
  "extraPostCSSPlugins": [
    PxToRem({
      rootValue: 41,
      propWhiteList: []
    })
  ],
  "proxy": {
    "/Api": {
      "target": "http://pre.startechsoft.cn",
      "changeOrigin": true,
      "pathRewrite": { "^/Api": "" }
    }
  },
}
